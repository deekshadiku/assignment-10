$(document).ready(function () {
  let password = "";
  let confirmPassword = "";
  let valid = [false, false, false, false, false];

  function handleOnChange() {
    if (this.id == "username") {
      valid[0] = this.value.length > 0;
    } else if (this.id == "password") {
      password = this.value;
      valid[1] = this.value.length >= 10;
    } else if (this.id == "confirmPassword") {
      confirmPassword = this.value;
      valid[2] = password.length >= 10 && confirmPassword === password;
    } else if (this.id == "checkbox") {
      valid[3] = this.checked;
    } else if (this.id == "countrySelect") {
      valid[4] = this.value != "select your country" ? true : false;
    }

    const allValid = valid.every((v) => v == true);
    $("#submitBtn").attr("disabled", !allValid);
  }

  countries.forEach((country) => {
    const optionHtml = `<option value="${country.code}">${country.name}</option>`;
    $("#countrySelect").append(optionHtml);
  });

  // form submission
  $("#form").submit(function (e) {
    e.preventDefault();
    const username = $("#username").val();
    const country = $("#countrySelect").val();
    const message = `<p class="message"> Welcome ${username}! The country code you selected is ${country} </p>`;
    $(".wrapper").append(message);

    this.reset();
    password = "";
    confirmPassword = "";
    valid = [false, false, false, false, false];
    $("#submitBtn").attr("disabled", true);
  });

  // disabling btn in the intial go
  $("#submitBtn").attr("disabled", true);

  // event listners
  $("#username").keyup(handleOnChange);
  $("#password").keyup(handleOnChange);
  $("#confirmPassword").keyup(handleOnChange);
  $("#checkbox").change(handleOnChange);
  $("#countrySelect").change(handleOnChange);
});
